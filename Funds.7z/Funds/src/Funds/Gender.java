package Funds;

public enum Gender {
    MALE,
    FEMALE;


}
