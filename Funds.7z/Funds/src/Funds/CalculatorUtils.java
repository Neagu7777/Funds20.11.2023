package Funds;

public class CalculatorUtils {
    public static double calculateAverage(int first, int second) {
        return (first + second) / 2.0;
    }

    public static double calculateAverage(int first, int second, int third) {
        return (first + second + third) / 3.0;
    }
}

