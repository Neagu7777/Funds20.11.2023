

import Funds.PensionFund;
import Funds.Worker;

import java.io.*;
import java.util.List;

public class PensionFundGenerator {

        static File generatedFund = new File("GeneratedFunds.txt");


        static FileReader fileReader;

        static {
            try {
                fileReader = new FileReader(generatedFund);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        }


        static BufferedReader bufferedReader = new BufferedReader(fileReader);

        public static List<Worker> generateWorkers(){
            List<Worker> workers = bufferedReader.lines()
                    .map(Worker::new)
                    .toList();
            return workers;
        }

    }
