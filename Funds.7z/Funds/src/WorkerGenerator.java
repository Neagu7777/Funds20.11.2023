import Funds.Worker;

import java.io.*;
import java.util.List;
import java.util.stream.Collectors;

public class WorkerGenerator {


        static File generatedPeopleFile = new File("GeneratedPeople.txt");


        static FileReader fileReader;

    static {
        try {
            fileReader = new FileReader(generatedPeopleFile);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }


    static BufferedReader bufferedReader = new BufferedReader(fileReader);

    public static List<Worker> generateWorkers() {
        List<Worker> workers = bufferedReader.lines()
                .map(Worker::new)
                .toList();
        return workers;
    }


}

